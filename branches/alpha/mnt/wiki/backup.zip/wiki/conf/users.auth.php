# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# user:MD5password:Real Name:email:groups,comma,seperated


mystdeim:5e8edd851d2fdfbd7415232c67367cc3:Novikov Roman:mystdeim@gmail.com:admin,user
