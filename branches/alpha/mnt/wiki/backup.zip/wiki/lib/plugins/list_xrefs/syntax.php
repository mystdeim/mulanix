<?php
if(!defined('DOKU_INC')) define('DOKU_INC',realpath(dirname(__FILE__).'/../../').'/');
if(!defined('DOKU_PLUGIN')) define('DOKU_PLUGIN',DOKU_INC.'lib/plugins/');
require_once(DOKU_PLUGIN.'syntax.php');

class syntax_plugin_list_xrefs extends DokuWiki_Syntax_Plugin {
 
    function getInfo(){
        return array(
            'author' => 'Troy Rollo',
            'email'  => 'dokuwiki@troy.rollo.name',
            'date'   => '2006-03-27',
            'name'   => 'Complex Lists Cross-References Plugin',
            'desc'   => 'Add cross-referencing to complex lists',
            'url'    => 'http://wiki.splitbrain.org/plugin:complex_lists'
        );
    }
 
    function syntax_plugin_list_xrefs(){
	$this->init = 0;
    }

    function getAllowedTypes()
    {
	return array('formatting', 'substition');
    }

    function getType(){
        return 'formatting';
    }
 
    function getSort(){
        return 15;
    }
 
    function connectTo($mode) {
	if (!$this->init)
	{
		$this->init = 1;
		$this->connectTo('plugin_list_xrefs');
	}
	$this->Lexer->addSpecialPattern('#[*@][^#]+#', $mode, 'plugin_list_xrefs');
	$this->Lexer->addEntryPattern('#[(]', $mode, 'plugin_list_xrefs');

    }

    function postConnect() {
	$this->Lexer->addExitPattern('[)]#', 'plugin_list_xrefs');
    }

    function handle($match, $state, $pos, &$handler){
        if ($state == DOKU_LEXER_SPECIAL)
	{
	    $str = trim($match, '#');
	    $tok = substr($str, 0, 1);
	    $str = substr($str, 1);
	    switch ($tok)
	    {
	    case '*':
		return array($state, 1, $str);

	    case '@':
		return array($state, 2, $str);
	    }
	}
        return array($state, $match);
    }

    function render($mode, &$renderer, $data) {
	if ($data[0] == DOKU_LEXER_SPECIAL)
	{
		$renderer->doc .= '<!--CPLX-LIST-XREF#' . $data[1] . '#' . $data[2] . '-->';
		return true;
	}
	else if ($data[0] == DOKU_LEXER_UNMATCHED)
	{
		$renderer->doc .= $data[1];
	}
        return false;
    }
 
}
 
//Setup VIM: ex: et ts=4 enc=utf-8 :
?>
